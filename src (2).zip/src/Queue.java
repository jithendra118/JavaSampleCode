public class Queue {

}
/**
 * 0 3 intiated
 * 6 3 proceesed and new batch 4 tasks intitated
 * 12 second batch of is processed and no more tasks
 *
 *
 *
 *
 */

