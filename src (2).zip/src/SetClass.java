import java.util.HashSet;
import java.util.Set;

public class SetClass {
    public static void main(String[] args) {
        Set<A1> set = new HashSet<>();
        A1 a= new A1("test","1");
        A1 b = new A1("test","1");
        System.out.println(set.add(a));
        System.out.println(set.add(b));
        String[] country = { "India", "Australia", "Japan", "USA", "UAE", "Canada", "Brazil"};
//length is an Array attribute that determines the array length
        int arrayLength=country.length;
//prints array length
       String temp =  country[6];
        System.out.println("The size of the array is: " + temp);
    }
}
class A1{
    String a;
    String b;

    public A1(String a, String b) {
        this.a = a;
        this.b = b;
    }

    public String getA() {
        return a;
    }

    public void setA(String a) {
        this.a = a;
    }

    public String getB() {
        return b;
    }

    public void setB(String b) {
        this.b = b;
    }
}