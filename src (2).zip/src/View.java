public class View {

    public static void main(String[] args) {
        StaticClass s1 = new StaticClass();
        int a = s1.n1;
        s1.m2();


    }
}
