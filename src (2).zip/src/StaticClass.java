public class StaticClass {
    public static int main;
public int n1;

    public static void m1(){
    System.out.println("Test this 1 static");
}

    public void m2(){
    System.out.println("normal class");
}

}
