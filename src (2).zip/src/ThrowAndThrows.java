import java.util.ArrayList;
import java.util.List;

public class ThrowAndThrows extends Few1{
   /* public void m1(){
        System.out.println("ThrowAndThrows");
    }*/
    public static void main(String[] args) {
        Few1 a = new ThrowAndThrows();
        a.m1();
        int[] test =null;
        if(false){
            test = new int[2];
        }else{
            test = new int[1];
        }

       // System.out.println(test[1]);
        List<String> s1 = new ArrayList<>();
        int[]  few = new int[s1.size()];

        System.out.println(few.length);

    }
}
class Few{
    public void m1(){
        System.out.println("m1 -Few");
    }
}

class Few1 extends Few{
    public void m1(){
        System.out.println("m1 -Few1");
    }
}
