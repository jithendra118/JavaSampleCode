public class ViewExample {
    public static void main(String[] args) {

    }
}
