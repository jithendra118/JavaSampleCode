public interface TestB {
    public int a=100;
    public void amount();
}
