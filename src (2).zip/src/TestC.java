public interface TestC {

    public void amount1();
}
